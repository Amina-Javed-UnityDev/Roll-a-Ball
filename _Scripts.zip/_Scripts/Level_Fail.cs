using System;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Level_Fail : MonoBehaviour
{
    [SerializeField]
    private UI_Manager uiManager;
    
    private void OnCollisionEnter(Collision player)
    {
        if (player.gameObject.CompareTag("Enemy"))
        {
            player.gameObject.SetActive(false);
            uiManager.levelFailPanel.SetActive(true);
        }
    }

    public void CloseLevelFailButton()
    {
        uiManager.levelFailPanel.SetActive(false);
        uiManager.mainMenuPanel.SetActive(true);
    }

    public void RetryButton()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name); //level restart
    }
}
