using UnityEngine;

public class GamePlay_panel : MonoBehaviour
{
    [SerializeField]
    private UI_Manager uiManager;

    public void PauseButton()
    {
        uiManager.pausePanel.SetActive(true);
    }
}
