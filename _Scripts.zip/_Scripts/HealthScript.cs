using TMPro;
using UnityEngine;
using UnityEngine.Rendering.Universal;
using UnityEngine.UI;

public class HealthScript : MonoBehaviour
{
    public float health;
    public TextMeshProUGUI healthText;

    void Start()
    {
        health = 100;
        UpdateHealthUI();
    }

    private void OnCollisionEnter(Collision other)
    {
        if (other.gameObject.CompareTag("Obstacles"))
        {
            ApplyDamage(0.1f);
            health = health - 10;
            UpdateHealthUI();
        }
    }

    void ApplyDamage(float damage)
    {
        health -= damage;

        if (health <= 0)
        {
            Debug.Log("Game Over");
        }

        UpdateHealthUI();
    }
    
    void UpdateHealthUI()
    {
        healthText.text ="Health :" + (health ).ToString("F0");
    }

}



