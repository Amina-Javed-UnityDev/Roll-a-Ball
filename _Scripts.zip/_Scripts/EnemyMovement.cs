using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class EnemyMovement : MonoBehaviour
{
    public Transform player;
    public NavMeshAgent navMeshAgent;

    [Header("Enemy Settings")]
    [Tooltip("Speed at which the enemy moves.")]
    public float enemySpeed = 3.5f; // Default NavMeshAgent speed

    void Start()
    {
        // Apply speed to the NavMeshAgent
        navMeshAgent.speed = enemySpeed;
    }

    void Update()
    {
        if (!navMeshAgent.isOnNavMesh)
        {
            Debug.LogWarning("Enemy is not on the NavMesh!");
            return;
        }

        if (PlayerController.isPlayerMoving)
        {
            navMeshAgent.SetDestination(player.position);
        }
    }
}