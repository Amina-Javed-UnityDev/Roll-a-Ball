using UnityEngine;

public class UI_Manager : MonoBehaviour
{
    public GameObject mainMenuPanel;
    public GameObject settingPanel;
    public GameObject gamePlayPanel;
    public GameObject pausePanel;
    public GameObject quitGamePanel;
    public GameObject warningPanel;
    public GameObject levelFailPanel;
    public GameObject objectivePanel;

 
}
