using UnityEngine;
using UnityEngine.UI;
using System.Collections; 


public class MainMenu_Panel : MonoBehaviour
{
    [SerializeField]
    private UI_Manager uiManager;
   
    
    public void PlayButtonActive()
    {
        StartCoroutine(StartGameAfterDelay(3f));
    }
    
    IEnumerator StartGameAfterDelay(float delay)
    {
        uiManager.objectivePanel.SetActive(true); // Hide objective
        yield return new WaitForSeconds(delay);

        //uiManager.gamePlayPanel.SetActive(true);

        uiManager.objectivePanel.SetActive(false); // Hide objective
        uiManager.gamePlayPanel.SetActive(true); // Start game
        uiManager.mainMenuPanel.SetActive(false);
    }

    public void SettingButtonActive()
    {
        uiManager.mainMenuPanel.SetActive(false);
        uiManager.settingPanel.SetActive(true);
    }

    public void QuitButtonActive()
    {
        uiManager.mainMenuPanel.SetActive(false);
        uiManager.quitGamePanel.SetActive(true);
    }
}
