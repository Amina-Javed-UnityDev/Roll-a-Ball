using UnityEngine;

public class Pause_Panel : MonoBehaviour
{
    [SerializeField] 
    private UI_Manager uiManager;
    
    public void YesResumeButton()
    {
        uiManager.pausePanel.SetActive(false);
        Time.timeScale = 1f; // Resumes the game
    }

    public void NoResumeButton()
    {
        uiManager.pausePanel.SetActive(false);
        uiManager.mainMenuPanel.SetActive(true);
    }
}
