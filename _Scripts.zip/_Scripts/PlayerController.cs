using UnityEngine;
using TMPro;
using System.Collections;
public class PlayerController : MonoBehaviour
{
    [SerializeField] 
    private UI_Manager uiManager;
    
    [Header("Movement Settings")]
    public float speed = 3f;
    private Rigidbody rb;

    [Header("UI Elements")]
    public TextMeshProUGUI countText;
    public GameObject winText;

    [Header("Joystick")]
    public FixedJoystick FixedJoystick;

    public static bool isPlayerMoving=false;
    private int count;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        count = 0;
        UpdateCountText();
        winText.SetActive(false);
    }

    void FixedUpdate()
    {
        Vector3 direction = new Vector3(FixedJoystick.Horizontal, 0f, FixedJoystick.Vertical);

        // Optional: ignore small joystick drift
        if (direction.magnitude > 0.1f)
        {
            isPlayerMoving = true;
            rb.AddForce(direction.normalized * speed, ForceMode.Force);
        }
        else
        {
            isPlayerMoving = false;
        }
    }

    void OnCollisionEnter(Collision collision)
    {
        GameObject other = collision.gameObject;

        if (other.CompareTag("PickUp"))
        {
            other.SetActive(false);
            count++;
            UpdateCountText();
        }

        if (other.CompareTag("Boundary") || other.CompareTag("Obstacles"))
        {
            Debug.Log("Collision Detected");
            StartCoroutine(WaitForWarning());
        }

        if (other.CompareTag("Enemy"))
        {
            Debug.Log("Level Failed");
            uiManager.levelFailPanel.SetActive(true);
        }
    }

    void UpdateCountText()
    {
        countText.text = "Count: " + count;

        if (count >= 12)
        {
            winText.SetActive(true);
        }
    }

    IEnumerator WaitForWarning()
    {
        uiManager.warningPanel.SetActive(true);
        yield return new WaitForSeconds(0.5f);
        uiManager.warningPanel.SetActive(false);
    }
}