using UnityEngine;

public class Warning_Panel : MonoBehaviour
{
    [SerializeField]
    private UI_Manager uiManager;
    

    public void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Obstacles"))
        {
            uiManager.warningPanel.SetActive(true);
            Invoke("HideWarning", 0.5f);
        }
    }

    public void HideWarning()
    {
        uiManager.warningPanel.SetActive(false);
    }
}
