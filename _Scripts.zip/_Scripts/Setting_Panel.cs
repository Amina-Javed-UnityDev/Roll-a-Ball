using UnityEngine;

public class Setting_Panel : MonoBehaviour
{
    [SerializeField]
    private UI_Manager uiManager;
    
    
    public void BackSettingButtonActive()
    {
        uiManager.settingPanel.SetActive(false);
        uiManager.mainMenuPanel.SetActive(true);
    }
}
