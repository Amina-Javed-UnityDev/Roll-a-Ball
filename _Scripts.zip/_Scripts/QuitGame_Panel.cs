using UnityEngine;
using UnityEngine.InputSystem.HID;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class QuitGame_Panel : MonoBehaviour
{
    [SerializeField]
    private UI_Manager uiManager;
    
    public void CloseQuitGamePanel()
    {
        uiManager.quitGamePanel.SetActive(false);
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    public void QuitGameButtonYes()
    {
        uiManager.quitGamePanel.SetActive(false);
        Application.Quit();
    }

    public void QuitGameButtonNo()  
    {
        uiManager.quitGamePanel.SetActive(false);
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}
